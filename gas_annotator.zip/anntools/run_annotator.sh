#!/bin/bash
cd /home/ubuntu/anntools
source /home/ubuntu/.virtualenvs/mpcs/bin/activate
python annotator.py